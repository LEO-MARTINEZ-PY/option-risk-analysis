# Option Pricing and Risk Analysis

📊 Simulação e precificação de opções europeias com Black-Scholes + análise de risco de carteira via Value at Risk (VaR).

## Tecnologias
- Python (NumPy, Pandas, Scipy)
- Jupyter Notebook

## Funcionalidades
- Precificação de opções do tipo call e put
- Simulação de retornos e cálculo de VaR (histórico)
- Visualização de risco para tomada de decisão

## Autor
Desenvolvido por Leonardo Martinez como parte do plano de transição para a área de risco e derivativos no mercado financeiro.
